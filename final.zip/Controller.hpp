#pragma once
#include "Repo.hpp"

class Controller
{
private:
	Repository repo;
	int currentStatueIndex;
	DynamicArray<GuardianStatue> myList;
public:
	/*
	Default constructor of the controller class
	*/
	Controller();
	/*
	Constructor for the controller class, initialised with a repository object as parameter
	*/
	Controller(Repository& repository);

	/*
	Based on the parameters from the UI, creates a Guardian Statue and sends it to repo for further adding.
	*/
	void addGuardianStatue(string& powerWord, string& material, int age, string& corporealForm);

	/*
	Gets as parameter from UI a power word and sends it to the repo for the deleting function
	*/
	void deleteGuardianStatue(string& powerWord);

	/*
	Gets as parameters a power word and new attributes(material, age, corporeal form) for the object having that power word.
	Creates objects and sends them to repo for the update function
	*/
	void updateGuardianStatue(string& powerWord, string& newMaterial, int newAge, string& newCorporealForm);

	/*
	Gets a copy of the statues list from the repo
	*/
	DynamicArray<GuardianStatue> getAllStatues();

	DynamicArray<GuardianStatue> getFilteredStatues(string& material, int age);

	GuardianStatue getNextGuardianStatue();

	void saveGuardianStatue(string& powerWord);

	DynamicArray<GuardianStatue> getMyList();


};